<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Pilih Event untuk Cetak Sertifikat</h2>
</div>

<div class="card shadow">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-download"></i> Download Sertifikat</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama Event</th>
                        <th>Tanggal Mulai</th>
                        <th>Tanggal Selesai</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($events)): ?>
                        <tr>
                            <td colspan="6" class="text-center">
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle"></i>
                                    Anda belum terdaftar di event manapun atau belum ada event yang selesai.
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php $no = 1; ?>
                        <?php foreach ($events as $event): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>
                                    <strong><?= esc($event['title']) ?></strong>
                                    <br>
                                    <small class="text-muted"><?= esc($event['location']) ?></small>
                                </td>
                                <td><?= esc(date('d/m/Y', strtotime($event['start_date']))) ?></td>
                                <td><?= esc(date('d/m/Y', strtotime($event['end_date']))) ?></td>
                                <td>
                                    <?php if ($event['end_date'] < date('Y-m-d H:i:s')): ?>
                                        <span class="badge bg-success">
                                            <i class="fas fa-check-circle"></i> Selesai
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">
                                            <i class="fas fa-clock"></i> Berlangsung
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($event['end_date'] < date('Y-m-d H:i:s')): ?>
                                        <a href="<?= base_url('/events/download-certificate/' . esc($event['id'])) ?>"
                                            class="btn btn-sm btn-success"
                                            title="Download PDF">
                                            <i class="fas fa-download"></i> Download PDF
                                        </a>
                                    <?php else: ?>
                                        <small class="text-muted">
                                            <i class="fas fa-clock"></i>
                                            Sertifikat tersedia setelah <?= esc(date('d/m/Y', strtotime($event['end_date']))) ?>
                                        </small>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if (!empty($events)): ?>
            <div class="mt-3">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    <strong>Informasi:</strong>
                    <ul class="mb-0">
                        <li>Sertifikat hanya dapat didownload setelah event selesai</li>
                        <li>Klik "Download PDF" untuk mengunduh sertifikat dalam format PDF</li>
                        <li>File PDF akan otomatis terdownload ke perangkat Anda</li>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
    .btn-group .btn {
        margin-right: 5px;
    }

    .btn-group .btn:last-child {
        margin-right: 0;
    }

    .badge {
        font-size: 12px;
        padding: 5px 8px;
    }

    .table td {
        vertical-align: middle;
    }

    .alert ul {
        padding-left: 20px;
        margin-top: 10px;
    }

    .alert ul li {
        margin-bottom: 5px;
    }
</style>